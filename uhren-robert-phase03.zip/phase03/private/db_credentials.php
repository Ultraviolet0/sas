<?php
// localhost connection
// Create PHP constants for the database connection
// Here is an example
// define("DB_SERVER", "localhost");

define("DB_SERVER", "localhost");
define("DB_USER", "sally");
define("DB_PASS", "P@ssw0rd123!");
define("DB_NAME", "salamanders");

// webhost connection
// use this connection when you upload your files to the webhost
// comment them out when working locally

// define("DB_SERVER", "localhost");
// define("DB_USER", "u612891864_sally");
// define("DB_PASS", "k3*E8j$SpVoA");
// define("DB_NAME", "u612891864_salamanders");
