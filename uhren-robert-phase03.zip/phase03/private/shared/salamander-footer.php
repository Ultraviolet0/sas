<footer>
  &copy; <?php echo date('Y'); ?> Southern Appalachian Salamanders

</footer>
</div>
</body>

</html>

<?php db_disconnect($db); ?>
